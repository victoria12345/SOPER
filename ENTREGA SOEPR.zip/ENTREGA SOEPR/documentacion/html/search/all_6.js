var searchData=
[
  ['main',['main',['../ejercicio2_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;ejercicio2.c'],['../ejercicio4_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;ejercicio4.c'],['../ejercicio6a_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;ejercicio6a.c'],['../ejercicio6b_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;ejercicio6b.c'],['../ejercicio9_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;ejercicio9.c']]],
  ['manejador_5fsigusr1',['manejador_SIGUSR1',['../ejercicio4_8c.html#af67f7ad6bdff3c40a6b1d97ae573fa4c',1,'ejercicio4.c']]]
];
