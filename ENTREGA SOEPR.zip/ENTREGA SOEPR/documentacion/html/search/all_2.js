var searchData=
[
  ['captura',['captura',['../ejercicio6b_8c.html#a5b409e9fb8655fe2a2a779781f3ce91d',1,'captura(int sennal):&#160;ejercicio6b.c'],['../ejercicio9_8c.html#a5b409e9fb8655fe2a2a779781f3ce91d',1,'captura(int sennal):&#160;ejercicio9.c']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../semaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c'],['../semaforos_8h.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'Crear_Semaforo(key_t key, int size, int *semid):&#160;semaforos.c']]]
];
