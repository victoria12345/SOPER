var searchData=
[
  ['down_5fsemaforo',['Down_Semaforo',['../semaforos_8c.html#a883244cd3b83c42cda23687da1b63369',1,'Down_Semaforo(int id, int num_sem, int undo):&#160;semaforos.c'],['../semaforos_8h.html#a883244cd3b83c42cda23687da1b63369',1,'Down_Semaforo(int id, int num_sem, int undo):&#160;semaforos.c']]],
  ['downmultiple_5fsemaforo',['DownMultiple_Semaforo',['../semaforos_8c.html#ab375ebfc38acbdced46e062a689d5fad',1,'DownMultiple_Semaforo(int id, int size, int undo, int *active):&#160;semaforos.c'],['../semaforos_8h.html#ab375ebfc38acbdced46e062a689d5fad',1,'DownMultiple_Semaforo(int id, int size, int undo, int *active):&#160;semaforos.c']]]
];
