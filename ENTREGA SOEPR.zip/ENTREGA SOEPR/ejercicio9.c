/**
* @brief Ejerciccio9
*
* @file ejercicio9.c
* @author Victoria Pelayo e Ignacio Rabunnal
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <sys/shm.h>
#include "semaforos.h"

#define SEMKEY 75798
#define CAJAS 2

/**
* @brief calcula un numero aleatorio entre un minimo y un maximo
* @param inf minimo
* @param supr maximo
* @return numero aleatorio entre esos dos
*
* @author Victoria Pelayo e Ignacio Rabunnal
*/
int aleatorio(int inf, int supr){
  if(supr == 0 || inf == 0 || supr < inf){
    return -1;
  }
  return inf + rand() % (supr-inf+1);
}

/**
* @brief funcion que captura una sennal y no hace nada
* @param sennal sennal que se recibe
*
* @author Victoria Pelayo e Ignacio Rabunnal
*/
void captura(int sennal){
  return;
}

/**
* @brief main del ejercicio 9
*
* @author Victoria Pelayo e Ignacio Rabunnal
*/
int main(void){
  int i,j, pid;
  int semid, global_hijo = 0;
  int sennal_n, hijo_n;
  int global = 0;
  int valor =0 ;
  int *hijos;
  char clientesCaja[CAJAS][30];
  char cuentaCaja[CAJAS][30];
  char fichSennal[30] = "sennal.txt";
  int status;
  int procesos = CAJAS;
  unsigned short *array;
  unsigned short a = 1;
  FILE *clientes[CAJAS];
  FILE *cajas[CAJAS];
  FILE *sennal;

  /*Array de los pid de los hijos*/
  hijos = (int*)malloc(sizeof(int)*CAJAS);

  /*Array para inicializar el semaforo a 1*/
  array = (unsigned short*)malloc(sizeof(unsigned short)*CAJAS+1);
  for(i = 0; i < CAJAS+1; i++){
    array[i] = a;
  }

  /*Creamos los semaforos*/
  if(Crear_Semaforo(SEMKEY,CAJAS + 1, &semid) == ERROR){
    printf("Error creando el primer semaforo\n");
    exit(ERROR);
  }

  if(Inicializar_Semaforo(semid, array) == ERROR){
    printf("Error al inicializar el semaforo\n");
    Borrar_Semaforo(semid);
    exit(ERROR);
  }

  /*Armamos las sennales*/
  if(signal(SIGUSR1,  captura) == SIG_ERR){
    printf("Error armando la sennal usr1\n");
    Borrar_Semaforo(semid);
    exit(ERROR);
  }

  if(signal(SIGUSR2, captura) == SIG_ERR){
    printf("Error armando la sennal SIGUSR2\n");
    Borrar_Semaforo(semid);
    exit(ERROR);
  }

/*Creamos las cuentas de los clientes*/
   printf("Recibimos las cuentas de los clientes...\n");
  for(i = 0; i < CAJAS; i++){
    sprintf(clientesCaja[i], "clientesCaja%d.txt", i);
    clientes[i] = fopen(clientesCaja[i], "w");

    if(!clientes[i]){
      printf("Error abriendo el fichero clientesCaja%d\n.txt", i);
      free(array);
      free(hijos);
      Borrar_Semaforo(semid);
      exit(ERROR);
    }

    for(j = 0; j < 50; j++){
      fprintf(clientes[i],"%d\n" ,aleatorio(0,300));
    }

    sprintf(cuentaCaja[i], "cuentaCaja%d.txt",i);
    if(fclose(clientes[i])!= 0){
      printf("Error al cerrar el fichero\n");
      free(array);
      free(hijos);
      Borrar_Semaforo(semid);
      exit(ERROR);
    }
  }

  /*Creamos tantos hijos como cajas*/
  for(i = 0; i < CAJAS; i++){
    pid = fork();

    /*CASO DEL PADRE*/
    if(pid > 0){
      hijos[i] = pid;

      while(procesos >0){
        pause();
        /*Cuando recibe la sennal lee de que tipo es*/
        sennal = fopen(fichSennal, "r");
        if(!sennal){
          printf("Error abriendo fichero sennal\n");
          free(array);
          free(hijos);
          Borrar_Semaforo(semid);
          exit(ERROR);
        }

        /*lee cual era la senna y de que hijo*/
        fscanf(sennal, "%d %d", &hijo_n, &sennal_n);
        if(fclose(sennal)!= 0){
          printf("Error cerrando cichero\n");
          free(array);
          free(hijos);
          Borrar_Semaforo(semid);
          exit(ERROR);
        }

        switch(sennal_n){
          /*Cuando ha llegado a 1000 o mas su caja*/
            case SIGUSR1:
              Down_Semaforo(semid, hijo_n, SEM_UNDO);
              global += 900;
              Up_Semaforo(semid, hijo_n, SEM_UNDO);
              Up_Semaforo(semid, CAJAS, SEM_UNDO);
              break;

            /*Cuando acaba*/
            case SIGUSR2:
              procesos--;
              Down_Semaforo(semid, hijo_n, SEM_UNDO);
              cajas[hijo_n] = fopen(cuentaCaja[hijo_n], "r");
              if(!cajas[hijo_n]){
                printf("Error abriendo fichero %s", cuentaCaja[hijo_n]);
                free(array);
                free(hijos);
                Borrar_Semaforo(semid);
                exit(ERROR);
              }

              fscanf(cajas[hijo_n],"%d", &valor);
              if(fclose(cajas[hijo_n])){
                printf("Error cerrando fichero %s", cuentaCaja[hijo_n]);
                free(array);
                free(hijos);
                Borrar_Semaforo(semid);
                exit(ERROR);
              }
              global += valor;

              Up_Semaforo(semid, hijo_n, SEM_UNDO);
              Up_Semaforo(semid, CAJAS, SEM_UNDO);
              printf("Quedan %d cajas abiertas\n", procesos);
              break;
        }
      }

    
    for(i = 0; i < CAJAS; i++){
      waitpid(hijos[i], &status, WUNTRACED | WCONTINUED);
    }
    printf("El total de euros ganados es %d\n", global);
  }else if(pid == 0){
    /*CASO  HIJO*/
    char* escribir;

    printf("Abriendo caja %d para atender a clientes\n", i);
    /*Se cerrara despues del for porque se tiene que leer las 50 veces*/
    clientes[i] = fopen(clientesCaja[i], "r");
    if(!clientes[i]){
      Borrar_Semaforo(semid);
      free(array);
      free(hijos);
      printf("Error abriendo cuenta clientes %d\n", i);
      exit(ERROR);
    }

    /*Leemos el dinero de la cuenta cliente de esta caja*/
    for(j = 0; j < 50; j++){
      Down_Semaforo(semid, i, SEM_UNDO);

      fscanf(clientes[i],"%d", &valor);

      global_hijo += valor;
      cajas[i] = fopen(cuentaCaja[i], "w");
      if(!cajas[i]){
        printf("Abriendo caja %d\n", i);
        Borrar_Semaforo(semid);
        free(array);
        free(hijos);
        exit(ERROR);
      }

      escribir = (char*)malloc(3);
      sprintf(escribir, "%d", global_hijo);
      fwrite(escribir, 1, sizeof(escribir), cajas[i]);
      free(escribir);
      fclose(cajas[i]);

      /*Si la caja tiene 1000 o mas euros llama al padre para que recoja el dinero*/
      if(global_hijo >= 1000){
        global_hijo -= 900;
        Down_Semaforo(semid, CAJAS, SEM_UNDO);
        sennal = fopen(fichSennal, "w");
        if(!sennal){
          printf("Error creando fichero sennal\n");
          Borrar_Semaforo(semid);
          free(array);
          free(hijos);
          exit(ERROR);
        }

        escribir = (char*)malloc(10);
        sprintf(escribir, "%d %d\n", i, SIGUSR1);
        fwrite(escribir, 1, sizeof(escribir), sennal);
        free(escribir);
        if(fclose(sennal)!=0){
          Borrar_Semaforo(semid);
          free(array);
          free(hijos);
          printf("Error cerrando fichero sennal.txt");
          exit(ERROR);
        }
        printf("Retirando 900 euros de la caja %d\n", i);
        kill(getppid(), SIGUSR1);
      }

      Up_Semaforo(semid, i, SEM_UNDO);
      sleep(aleatorio(1,5));
    }

    if(fclose(clientes[i]) != 0){
      printf("Error al cerrar %s", clientesCaja[i]);
      Borrar_Semaforo(semid);
      free(array);
      free(hijos);
      exit(ERROR);
    }
    Down_Semaforo(semid, CAJAS, SEM_UNDO);
    sennal = fopen(fichSennal, "w");
    if(!sennal){
      printf("Error al abrir fichero sennal\n");
      Borrar_Semaforo(semid);
      free(array);
      free(hijos);
      exit(ERROR);
    }

    /*envia al padre senna de que ha acabado*/
    escribir = (char*)malloc(10);
    sprintf(escribir, "%d %d\n", i, SIGUSR2);
    fwrite(escribir,1,sizeof(escribir), sennal );
    free(escribir);

    if(fclose(sennal)!= 0){
      printf("Error al cerrar fichero sennal.txt");
      Borrar_Semaforo(semid);
      free(array);
      free(hijos);
      exit(ERROR);
    }
    printf("la caja %d ha terminado\n",i);
    kill(getppid(), SIGUSR2);
    exit(EXIT_SUCCESS);

  }else{
    Borrar_Semaforo(semid);
    free(array);
    printf("Error en creacion de un hijo\n");
    exit(ERROR);
  }
}

  Borrar_Semaforo(semid);
  free(array);
  free(hijos);
  return 0;

}
